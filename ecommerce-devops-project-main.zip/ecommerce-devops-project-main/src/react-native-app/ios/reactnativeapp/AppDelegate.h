// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0
#import <RCTAppDelegate.h>
#import <UIKit/UIKit.h>
#import <Expo/Expo.h>

@interface AppDelegate : EXAppDelegateWrapper

@end
